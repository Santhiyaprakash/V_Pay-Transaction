<?php
$uname=$_POST["username"];
$password=$_POST["password"];
$conn=new mysqli("localhost","root","","learn");

//check connection
//if($conn->connect_error){
   //die("Connection failed: ".$conn->connect_error);
//}
//else{
    //echo"Connection Successful!<br>";
//}
$stmt=$conn->prepare("SELECT * FROM learn.users WHERE uname=? and password=?");
$stmt->bind_param("ss",$uname,$password);

//sss means datatype string
if($stmt->execute()===TRUE){
    $res=$stmt->get_result();
    if($res->num_rows>0){
        echo "User Found!<br>";
        header("location:dashboard.php");
        exit();
    }
    else{
        echo " No user found<br>";
        echo"<a href='login.html'>try again</a>";
    }}

else{
    echo "Insert Failed: " .$stmt->error;
}
    ?>