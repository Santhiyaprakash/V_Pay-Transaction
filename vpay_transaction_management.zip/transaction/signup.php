<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
    input {
        text-align: center;
      }
      ::-webkit-input-placeholder {
        text-align: center;
      }
      :-moz-placeholder {
        text-align: center;
      }
        
        body{
            background-image:url(bg\ image.jfif);
            background-repeat: no-repeat;
            background-size: cover;
        }
        .box{
            margin-top: 20%;
            width: 300px;
            height:180px;
            background-color: rgb(206, 177, 177);
        }
    </style>
</head>
<body>
    <center>
        <div class="box">
            <h1 style="color:rgb(27, 21, 21)">Login Page</h1>
            <form action="signup.php" method="post">
                <input type="text" name="Accountholder name"  placeholder="Accountholder name"> <br>
                <br>
                <input type="text" name="Account Number"  placeholder="Account Number"> <br>
                <br>
                <input type="text" name="IFSC Code"  placeholder="IKSC Code"> <br>
                <br>
                <input type="text" name="Phone Number"  placeholder="Phone Number"> <br>
                <br>
                <input type="text" name="Email"  placeholder="Email"> <br>
                <br>
                <input type="password" name="Password" placeholder="Password"> <br> 
                <br>
                <input type="password" name="Comfirm Password" placeholder="Confirm Password"> <br> 
                <br>
                <input type="submit" value="submit" placeholder="Submit"> <br>
            </form>
            <form action="login.php" method="post">
            <h1 style="color:rgb(27, 21, 21)"></h1>
            </form>
        </div>
    </center>
    
    
    
</body>
</html>