<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Table</title>
    <style>
        table {display:flex;
            align-item:center;
            justify-content:center;
            border-collapse: collapse;
            width: 50%;
            margin-top: 20%;
            margin-left: 20%;
        }
        body{
            background-image:url(image4.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "transaction";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM trans";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>S.No</th><th>TITLE</th><th>AMOUNT</th><th>DATE</th><th>DESCRIPTION</th></tr>";
    // Output data of each row
    $serialNumber = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $serialNumber . "</td>";
        echo "<td>" . $row["title"] . "</td>";
        echo "<td>" . $row["amount"] . "</td>";
        echo "<td>" . $row["date"] . "</td>";
        echo "<td>" . $row["description"] . "</td>";
        echo "</tr>";
        $serialNumber++;
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

</body>
</html>
