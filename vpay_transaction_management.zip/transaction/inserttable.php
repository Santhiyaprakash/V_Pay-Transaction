<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "transaction";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$title = $_POST['title'];
$amount = $_POST['amount'];
$date = $_POST['date'];
$description = $_POST['description'];

$sql = "INSERT INTO trans (title, amount, date, description) VALUES ('$title', $amount, '$date', '$description')";

if ($conn->query($sql) === TRUE) {
    echo "Record added successfully";
    header("Location:showtable.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

</body>
</html>